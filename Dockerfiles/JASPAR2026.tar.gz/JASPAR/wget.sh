wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_redundant_pfms_transfac.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_non-redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_non-redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_non-redundant_pfms_transfac.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_vertebrates_non-redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_vertebrates_non-redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_vertebrates_non-redundant_pfms_transfac.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_vertebrates_redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_vertebrates_redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2026/CORE/JASPAR2026_CORE_vertebrates_redundant_pfms_transfac.txt

exit
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_redundant_pfms_transfac.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_non-redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_non-redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_non-redundant_pfms_transfac.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_non-redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_non-redundant_pfms_transfac.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_redundant_pfms_jaspar.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_redundant_pfms_meme.txt
wget https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_redundant_pfms_transfac.txt
