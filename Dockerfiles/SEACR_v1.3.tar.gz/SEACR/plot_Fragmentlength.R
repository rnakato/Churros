# https://www.protocols.io/view/cut-amp-tag-data-processing-and-analysis-tutorial-bjk2kkye.html
args <- commandArgs(trailingOnly=TRUE)
inputfile <- args[1]
output <- args[2]

library(dplyr)
library(ggplot2)
library(viridis)

fragLen = c()
fragLen = read.table(inputfile, header = FALSE) %>%
          mutate(fragLen = V1 %>% as.numeric, fragCount = V2 %>% as.numeric, Weight = as.numeric(V2)/sum(as.numeric(V2)))

fig5B = fragLen %>% ggplot(aes(x = fragLen, y = fragCount)) +
  geom_line(size = 1) +
  scale_color_viridis(discrete = TRUE, begin = 0.1, end = 0.9, option = "magma") +
  theme_bw(base_size = 20) +
  xlab("Fragment Length") +
  ylab("Count") +
  coord_cartesian(xlim = c(0, 500))

ggsave(output)
